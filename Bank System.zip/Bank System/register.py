#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

reqobj=cgi.FieldStorage()
id=reqobj.getvalue("uid")
pas=reqobj.getvalue("pass")
unm=reqobj.getvalue("nm")
gn=reqobj.getvalue("gen")
ct=reqobj.getvalue("cty")
no=reqobj.getvalue("No.")
em=reqobj.getvalue("Eml")

#print(id+pas)
con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()
try:
    curs.execute("insert into users value('%s','%s','%s','%s','%s','%s','%s')" %(id,pas,unm,gn,ct,no,em))
    con.commit()
    print("<h3> User Registered Succesfully </h3>")
except Exception as e:
    print("<h3> Registration Failed </h3>")
    print(e)

con.close()
print('<hr>')

print("<br><a href='index.html'>Home</a>")