#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
fan=int(req.getvalue("fan"))
tan=int(req.getvalue("tan"))
amt=float(req.getvalue("am"))

con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()
data=curs.execute("select * from accounts where accno=%d"%fan)
if data:
    try:
        curs.execute("update accounts set balance=balance-%.2f where accno=%d"%(amt,fan))
        curs.execute("update accounts set balance=balance+%.2f where accno=%d"%(amt,tan))
        curs.execute("insert into translog(fromacc,toacc,amount,transdt) values(%d,%d,%.2f,now())"%(fan,tan,amt))

        con.commit()
        print("<h2> Money Transferred Successfully..</h2>")

    except Exception as e:
        print(e)
else:
    print("<h2>Invalid Account No.</h2>")


con.close()
print('<hr>')

print("<br><a href='Admin.html'>Refresh..</a>")
#print("update accounts set balance=balance-%.2f where accno=%d"%(amt,fan))
#print("update accounts set balance=balance+%.2f where accno=%d"%(amt,tan))