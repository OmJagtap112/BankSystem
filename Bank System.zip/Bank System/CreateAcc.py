#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
ano=int(req.getvalue("ano"))
anm=req.getvalue("anm")
atyp=req.getvalue("atyp")
bal=float(req.getvalue("bal"))

con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

try:
    curs.execute("insert into accounts values(%d,'%s','%s',%.2f)"%(ano,anm,atyp,bal))
    con.commit()
    print("<h2>Account Opened Successfully...</h2>")
except Exception as e:
    print("Error : ",e)

con.close()
print('<hr>')

print("<br><a href='Admin.html'>Refresh..</a>")