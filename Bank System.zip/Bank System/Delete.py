#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
tan=int(req.getvalue("ano"))

con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()
data=curs.execute("select * from accounts where accno=%d"%tan)
if data:
    try:
        curs.execute("delete from accounts where accno=%d"%tan)
        con.commit()
        print("<h2> Account Deleted Successfully</h2>")
    except Exception as e:
        print(e)

else:
    print("<h2>Invalid Account Number</h2>")

con.close()

print('<hr>')

print("<br><a href='Admin.html'>Refresh..</a>")
