#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
#import cgi
import pymysql

print("Content-type:text/html")
print()
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'><br>")
con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

curs.execute("select * from translog")
data=curs.fetchall()
print("<h2>Transactions Details.</h2>")

'''for rec in data:
    print("<h5>")
    print("From Account : ",rec[1],"||","To Account : ",rec[2],"||","Balance : ",rec[3],"||",rec[4])
    print("<h5/>")
'''
print("<table class='table table-bordered table-hover'>")
print("<tr style='background color:azure'>")
print("<th>No.")
print("<th>From Account")
print("<th>To account")
print("<th>Amount")
print("<th>Date and Time")
print("</tr>")

for rec in data:
    print("<tr>")
    print("<td>%d" %rec[0])
    print("<td>%d" %rec[1])
    print("<td>%d" %rec[2])
    print("<td>%.2f" %rec[3])
    print("<td>" ,rec[4])
    print("</tr>")

con.close()
print("</table>")
print("<br><a href='Admin.html'><b>Refresh..</b></a>")
print("</div>")

