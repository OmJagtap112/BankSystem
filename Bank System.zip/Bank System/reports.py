#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
#import cgi
import pymysql

print("Content-type:text/html")
print()
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'><br>")
con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

curs.execute("select * from accounts")
data=curs.fetchall()
print("<h2 class='display-5'> Accounts Report</h2><hr>")

print("<table class='table table-bordered table-hover'>")
print("<tr style='background-color:azure'>")
print("<th>Number")  
print("<th>Name")
print("<th>Type")
print("<th>Balance")
print("</tr>")

for rec in data:
    print("<tr>")
    print("<td>%d" %rec[0])
    print("<td>%s" %rec[1])
    print("<td>%s" %rec[2])
    print("<td>%.2f" %rec[3])
    print("</tr>")

con.close()
print("</table>")
print("</div>")